<template>
 <div class="Home">
    <h1>This is an ProfileDetail page </h1>
  </div>
</template>
