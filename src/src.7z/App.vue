<template>
  <v-app id="inspire">
    <v-app-bar app color="white" flat>
      <v-tabs centered class="ml-n1" color="grey darken-1">
        <v-tab v-for="link in links" :key="link">
          <h3>{{ link }}</h3>
        </v-tab>
      </v-tabs>

      <h6 v-if="isLogin">{{ userInfo.name }} {{ userInfo.userid }}</h6>

      <v-btn
        x-small
        color="secondary"
        flat
        v-if="isLogin"
        @click="$store.dispatch('logout')"
        >Logout</v-btn
      >
      <v-btn
        small
        v-else
        color="primary"
        class="ma-2 white--text"
        router
        :to="{ name: 'Login' }"
      >
        Login
        <v-icon right dark>
          mdi-login
        </v-icon>
      </v-btn>
      <v-spacer></v-spacer>
      <v-btn
        x-small
        color="primary"
        flat
        v-if="isAdminLogin"
        router
        :to="{ name: 'Signin' }"
        >Sign in</v-btn
      >
    </v-app-bar>
    <v-main  class="grey lighten-3" >
      <v-container>
        <v-row>
          <v-col xl="12" >
            <v-sheet min-height="70vh" rounded="lg" >
              <!--  -->
              <v-bottom-navigation>
                <v-btn value="Home" @click="$router.push({ name: 'Home' })">
                  <span>Home</span>
                  <v-icon>mdi-home</v-icon>
                </v-btn>
                <v-btn
                  value="ScrapInput"
                  router
                  :to="{
                    name: 'ScrapInput',
                    params: {
                      userID: 4321,
                      name: 'winaki',
                    },
                    query: {
                      group: 'member',
                      catagory: 'trial',
                    },
                  }"
                >
                  <span>ScrapInOut</span>
                  <v-icon>mdi-pencil</v-icon>
                </v-btn>
                <v-btn
                  value="ScrapOutHistory"
                  router
                  :to="{
                    name: 'ScrapOutHistory',
                    query: {
                      group: 'member',
                      catagory: 'trial',
                    },
                  }"
                >
                  <span>ScrapOutHistory</span>
                  <v-icon>mdi-monitor</v-icon>
                </v-btn>
                 <v-menu
                    v-for="([text, rounded], index) in subMenuBtns"
                    :key="text"
                    :rounded="rounded"
                    offset-y
                  >
                    <template v-slot:activator="{ attrs, on }">
                      <v-btn
                        :color="colors[index]"
                        v-bind="attrs"
                        v-on="on"
                      >
                        <span>{{ text }} </span>
                        <v-icon>mdi-pencil</v-icon>
                      </v-btn>
                    </template>

                    <v-list>
                      <v-list-item
                         :to="item.route" 
                        v-for="item in subMenuItems"
                        :key="item.title"                        
                        link
                      >
                        <v-list-item-title v-text="item.title"></v-list-item-title>
                      </v-list-item>
                    </v-list>
                  </v-menu>
              </v-bottom-navigation>
              <keep-alive v-if="$route.meta.keepAlive">
                  <router-view></router-view>                
              </keep-alive>
              <router-view v-else></router-view>
            </v-sheet>
          </v-col>
        </v-row>
      </v-container>

    </v-main>
    <v-footer color="secondary" dark fixed>
      <div class="mx-auto">
        Copyright &copy; {{ new Date().getFullYear()}}
      </div>
    </v-footer>
  </v-app>
</template>

<script>
import { mapState } from "vuex";

export default {
  data: () => ({
    links: ["O/D Scrap","Truck-Scale"],
    loginUser: null,
    events: ["click", "mousemove", "mousedown", "scroll", "keypress", "load"],

    logoutTimer: null,

    subMenuBtns: [
        ['Item Code List ', '0'],
      ],
    items: [...Array(4)].map((_, i) => `Item ${i}`),
    colors: ['normal', 'error', 'teal darken-1'],
    subMenuItems: [ 
                    {title: "Item Code"           ,route: "/ItemCode"}, 
                    {title: "Trade Customer"      ,route: "/Customer"}, 
                    {title: "Customer Trade Item" ,route: "/"},
                    {title: "Catagory"            ,route: "/ScrapOutHistory"}, 
                    {title: "Truck"               ,route: "/"},
                    {title: "Scale data "         ,route: "/ScrapInput"} 
                  ],
  }),

  methods: {
    test() {
      alert("test");
    },
    resetTimer: function() {
      clearTimeout(this.logoutTimer);
      this.setTimers();
    },
    setTimers: function() {
      this.logoutTimer = setTimeout(this.autoLogoutUser, 5 * 60 * 1000); // 30 minutes
    },

    autoLogoutUser() {
      if (this.isLogin === true) {
        alert("Are you still here ? system auto logout !!");
        this.$store.dispatch("logout");
      }
    },

    movetoScreen(item) {

      //user is not authorized
      if (localStorage.getItem("token") === null) {
        this.$router.push("/login");
      }

      switch (item) {
          case "Item Code":
              if (localStorage.getItem("token") === null) {
                this.$router.push("/ScrapInput");
              }
              break;

          case "winaki":
              break;
        }
    }

  },
  computed: {
    ...mapState(["isLogin", "userInfo", "isAdminLogin"]),
  },
  created() {
    console.log("vue created ");

    //user is not authorized
    if (localStorage.getItem("token") === null) {
      this.$router.push("/login");
    }

    /*
      if (this.userInfo === null) {
        this.loginUser = "Login"
        console.log("userInfo null ")
      }
      else {
        console.log("userInfo not null ")
        this.loginUser = this.userInfo.name
      }
      */
  },

  mounted() {
    this.events.forEach(function(event) {
      window.addEventListener(event, this.resetTimer);
    }, this);

    this.setTimers();
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}
</style>
